-- ML Results --
SELECT
    TOP 10 *
FROM
    OPENROWSET(
        BULK 'https://capstonegroup.dfs.core.windows.net/project-container/BI/ml_result.csv',
        FORMAT = 'CSV',
        PARSER_VERSION = '2.0',
        HEADER_ROW = TRUE
    ) AS [result]


-- User Analysis --
SELECT
    TOP 100 *
FROM
    OPENROWSET(
        BULK 'https://capstonegroup.dfs.core.windows.net/project-container/ml_training/users.csv',
        FORMAT = 'CSV',
        PARSER_VERSION = '2.0',
        HEADER_ROW = TRUE
    ) AS [result]


-- most negative user --
SELECT
    TOP 50 *
FROM
    OPENROWSET(
        BULK 'https://capstonegroup.dfs.core.windows.net/project-container/landing/most_negative_users.csv/part-00000-tid-3890166539028929442-f30692fb-2e5d-439a-9b7a-c5b4a351523f-125-1-c000.csv',
        FORMAT = 'CSV',
        PARSER_VERSION = '2.0',
        HEADER_ROW=TRUE
    ) AS [result]